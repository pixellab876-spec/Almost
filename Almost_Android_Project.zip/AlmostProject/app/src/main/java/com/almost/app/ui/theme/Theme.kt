package com.almost.app.ui.theme
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Light = lightColorScheme(primary = ForestGreen, secondary = Color(0xFF3B6454), background = BackgroundLight, surface = Color.White)
private val Dark = darkColorScheme(primary = ForestGreenLight, background = BackgroundDark, surface = Color(0xFF1A1C1A))
@Composable fun AlmostTheme(themeMode: ThemeMode = ThemeMode.SYSTEM, content: @Composable () -> Unit) {
    val dark = when (themeMode) { ThemeMode.SYSTEM -> isSystemInDarkTheme(); ThemeMode.LIGHT -> false; ThemeMode.DARK -> true }
    MaterialTheme(colorScheme = if (dark) Dark else Light, content = content)
}
