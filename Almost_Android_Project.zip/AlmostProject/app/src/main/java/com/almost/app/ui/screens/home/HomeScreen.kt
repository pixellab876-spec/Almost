package com.almost.app.ui.screens.home

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.almost.app.domain.prediction.PredictionService
import com.almost.app.ui.viewmodel.HomeViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun HomeScreen(onAdd: () -> Unit, onDetail: (Long) -> Unit, onSettings: () -> Unit, vm: HomeViewModel = viewModel()) {
    val items by vm.items.collectAsState(); var search by remember { mutableStateOf("") }; var filter by remember { mutableStateOf("All") }
    val filtered = items.filter { it.name.contains(search, true) && (filter == "All" || PredictionService.calculate(it).status == filter || (filter == "Attention" && PredictionService.calculate(it).status in listOf("Running low", "Almost finished", "Finished"))) }
    Scaffold(topBar = { TopAppBar(title = { Column { Text("Almost"); Text("Never run out unexpectedly.", style = MaterialTheme.typography.labelSmall) } }, actions = { IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, "Settings") } }) }, floatingActionButton = { FloatingActionButton(onClick = onAdd) { Icon(Icons.Default.Add, "Add item") } }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) { Summary("Tracked", items.size, Modifier.weight(1f)); Summary("Low", items.count { PredictionService.calculate(it).status == "Running low" }, Modifier.weight(1f)); Summary("Empty", items.count { it.currentQuantity <= 0 }, Modifier.weight(1f)) }
            Spacer(Modifier.height(12.dp)); OutlinedTextField(search, { search = it }, Modifier.fillMaxWidth(), label = { Text("Search essentials") }, singleLine = true)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("All", "Attention", "Healthy", "Running low", "Almost finished", "Finished").forEach { FilterChip(selected = filter == it, onClick = { filter = it }, label = { Text(it) }) } }
            if (filtered.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text(if (items.isEmpty()) "No essentials yet. Tap + to add your first item." else "No items match your search.") }
            else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 88.dp)) { items(filtered, key = { it.id }) { item ->
                val p = PredictionService.calculate(item)
                Card(Modifier.fillMaxWidth().clickable { onDetail(item.id) }) { Column(Modifier.padding(16.dp)) { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(item.name, style = MaterialTheme.typography.titleMedium); Text(p.status, color = when(p.status) { "Finished", "Almost finished" -> MaterialTheme.colorScheme.error; "Running low" -> MaterialTheme.colorScheme.tertiary; else -> MaterialTheme.colorScheme.primary }) }; Text("${item.currentQuantity} ${item.unit} · ${item.category}"); Text(if (p.daysRemaining == null) "Add daily usage to estimate finish date" else "About ${p.daysRemaining.toInt()} days remaining"); p.predictedFinishDate?.let { Text("Estimated finish: ${SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(it))}", style = MaterialTheme.typography.bodySmall) } } }
            } }
        }
    }
}
@Composable private fun Summary(label: String, count: Int, modifier: Modifier = Modifier) { Card(modifier.widthIn(min = 82.dp)) { Column(Modifier.padding(12.dp)) { Text(label, style = MaterialTheme.typography.labelSmall); Text(count.toString(), style = MaterialTheme.typography.titleLarge) } } }
