package com.almost.app.ui.screens.detail

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.ui.platform.LocalContext
import com.almost.app.domain.prediction.PredictionService
import com.almost.app.ui.viewmodel.ItemDetailViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun ItemDetailScreen(itemId: Long, onBack: () -> Unit, onEdit: (Long) -> Unit, onDeleted: () -> Unit) {
    val app = LocalContext.current.applicationContext as android.app.Application
    val vm: ItemDetailViewModel = viewModel(key = "detail-$itemId", factory = ItemDetailFactory(app, itemId))
    val item by vm.item.collectAsState(); val consumption by vm.consumption.collectAsState(); val restocks by vm.restocks.collectAsState()
    var amount by remember { mutableStateOf("") }; var error by remember { mutableStateOf<String?>(null) }; var action by remember { mutableStateOf("Consume") }; var confirmDelete by remember { mutableStateOf(false) }
    Scaffold(topBar = { TopAppBar(title = { Text(item?.name ?: "Item details") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") } }) }) { padding ->
        if (item == null) Box(Modifier.fillMaxSize().padding(padding)) { Text("Loading item…") } else {
            val current = item!!; val p = PredictionService.calculate(current)
            LazyColumn(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item { Text("${current.currentQuantity} ${current.unit} remaining", style = MaterialTheme.typography.headlineSmall); Text("Status: ${p.status}"); Text(p.daysRemaining?.let { "Estimated days remaining: ${"%.1f".format(it)}" } ?: "Prediction unavailable: enter a daily usage estimate"); p.predictedFinishDate?.let { Text("Estimated finish: ${SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(it))}") }; Text("Daily usage: ${current.dailyUsageEstimate} ${current.unit}/day"); Text("Prediction confidence: ${p.confidence}") }
                item { OutlinedTextField(amount, { amount = it }, Modifier.fillMaxWidth(), label = { Text("Quantity") }); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Button(onClick = { action = "Consume"; val a = amount.toDoubleOrNull(); if (a == null) error = "Enter a valid quantity" else vm.consume(a) { error = it; if (it == null) amount = "" } }) { Text("Record consumption") }; OutlinedButton(onClick = { action = "Restock"; val a = amount.toDoubleOrNull(); if (a == null) error = "Enter a valid quantity" else vm.restock(a) { error = it; if (it == null) amount = "" } }) { Text("Restock") } }; error?.let { Text(it, color = MaterialTheme.colorScheme.error) }; OutlinedButton(onClick = { onEdit(current.id) }, Modifier.fillMaxWidth()) { Text("Edit item") }; TextButton(onClick = { confirmDelete = true }) { Text("Delete item", color = MaterialTheme.colorScheme.error) } }
                item { Text("Consumption history", style = MaterialTheme.typography.titleMedium) }; items(consumption) { Text("−${it.quantityConsumed} ${current.unit} · ${SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(it.timestamp))}") }
                item { Text("Restock history", style = MaterialTheme.typography.titleMedium) }; items(restocks) { Text("+${it.quantityAdded} ${current.unit} · ${SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(it.timestamp))}") }
            }
        }
    }
    if (confirmDelete) AlertDialog(onDismissRequest = { confirmDelete = false }, title = { Text("Delete ${item?.name}?") }, text = { Text("This removes the item from inventory.") }, confirmButton = { TextButton(onClick = { confirmDelete = false; vm.delete(onDeleted) }) { Text("Delete") } }, dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } })
}
