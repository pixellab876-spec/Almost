package com.almost.app.data.local.entity
import androidx.room.Entity
import androidx.room.PrimaryKey
@Entity(tableName = "consumption_records")
data class ConsumptionRecordEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val inventoryItemId: Long, val quantityConsumed: Double, val timestamp: Long = System.currentTimeMillis(), val notes: String? = null)
