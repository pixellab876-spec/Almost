package com.almost.app.data.local.entity
import androidx.room.Entity
import androidx.room.PrimaryKey
@Entity(tableName = "notification_records")
data class NotificationRecordEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val inventoryItemId: Long, val reminderType: String, val scheduledDate: Long, val isDelivered: Boolean = false)
