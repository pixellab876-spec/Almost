package com.almost.app.ui.theme
import androidx.compose.ui.graphics.Color
val ForestGreen = Color(0xFF2E7D32)
val ForestGreenLight = Color(0xFF81C784)
val BackgroundLight = Color(0xFFF8F9F7)
val BackgroundDark = Color(0xFF121412)
val StatusHealthy = Color(0xFF388E3C)
val StatusLow = Color(0xFFF57C00)
val StatusCritical = Color(0xFFD32F2F)
