package com.almost.app.ui.screens.settings

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.almost.app.ui.theme.ThemeMode
import com.almost.app.ui.viewmodel.SettingsViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun SettingsScreen(vm: SettingsViewModel, onBack: () -> Unit) {
    val state by vm.uiState.collectAsState()
    Scaffold(topBar = { TopAppBar(title = { Text("Settings") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") } }) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text("Appearance", style = MaterialTheme.typography.titleMedium)
            ThemeMode.values().forEach { mode -> Row { RadioButton(selected = state.themeMode == mode, onClick = { vm.setTheme(mode) }); Text(mode.name.lowercase().replaceFirstChar { it.uppercase() }, Modifier.padding(top = 12.dp)) } }
            HorizontalDivider(); Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("Enable reminder notifications", Modifier.weight(1f)); Switch(checked = state.notificationsEnabled, onCheckedChange = vm::setNotifications) }
            Text("Default reminder lead time", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf(1, 3, 7).forEach { OutlinedButton(onClick = { vm.setLeadTime(it) }) { Text(if (state.defaultLeadTime == it) "✓ $it days" else "$it days") } } }
            Text("Almost works offline. Reminder checks run periodically; Android may delay background work, so exact notification timing is not guaranteed.", style = MaterialTheme.typography.bodySmall)
            Text("About Almost", style = MaterialTheme.typography.titleMedium); Text("Never run out unexpectedly. Inventory data is stored locally on this device.")
        }
    }
}
