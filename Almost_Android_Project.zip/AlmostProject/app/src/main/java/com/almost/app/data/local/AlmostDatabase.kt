package com.almost.app.data.local
import androidx.room.Database
import androidx.room.RoomDatabase
import com.almost.app.data.local.dao.InventoryDao
import com.almost.app.data.local.entity.*
@Database(entities = [InventoryItemEntity::class, ConsumptionRecordEntity::class, RestockRecordEntity::class, NotificationRecordEntity::class], version = 1, exportSchema = false)
abstract class AlmostDatabase : RoomDatabase() { abstract fun inventoryDao(): InventoryDao }
