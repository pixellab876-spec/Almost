package com.almost.app.data.local.dao

import androidx.room.*
import com.almost.app.data.local.entity.*
import kotlinx.coroutines.flow.Flow

@Dao
interface InventoryDao {
    @Query("SELECT * FROM inventory_items ORDER BY name COLLATE NOCASE") fun getAllItemsFlow(): Flow<List<InventoryItemEntity>>
    @Query("SELECT * FROM inventory_items WHERE id = :id") suspend fun getItemById(id: Long): InventoryItemEntity?
    @Query("SELECT * FROM inventory_items WHERE id = :id") fun getItemFlowById(id: Long): Flow<InventoryItemEntity?>
    @Insert suspend fun insertItem(item: InventoryItemEntity): Long
    @Update suspend fun updateItem(item: InventoryItemEntity)
    @Delete suspend fun deleteItem(item: InventoryItemEntity)
    @Insert suspend fun insertConsumptionRecord(record: ConsumptionRecordEntity)
    @Insert suspend fun insertRestockRecord(record: RestockRecordEntity)
    @Insert suspend fun insertNotificationRecord(record: NotificationRecordEntity)
    @Query("SELECT * FROM consumption_records WHERE inventoryItemId = :id ORDER BY timestamp DESC") fun consumptionHistory(id: Long): Flow<List<ConsumptionRecordEntity>>
    @Query("SELECT * FROM restock_records WHERE inventoryItemId = :id ORDER BY timestamp DESC") fun restockHistory(id: Long): Flow<List<RestockRecordEntity>>
    @Query("SELECT * FROM notification_records WHERE inventoryItemId = :id AND reminderType = :type AND scheduledDate = :date LIMIT 1") suspend fun findNotification(id: Long, type: String, date: Long): NotificationRecordEntity?
    @Query("SELECT * FROM inventory_items") suspend fun getAllItemsOnce(): List<InventoryItemEntity>
}
