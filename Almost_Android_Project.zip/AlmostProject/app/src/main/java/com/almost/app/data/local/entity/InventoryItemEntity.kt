package com.almost.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "inventory_items")
data class InventoryItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val category: String = "General",
    val currentQuantity: Double,
    val unit: String,
    val dailyUsageEstimate: Double = 0.0,
    val reminderLeadTime: Int = 3,
    val minimumQuantityThreshold: Double = 0.0,
    val createdDate: Long = System.currentTimeMillis(),
    val lastUpdatedDate: Long = System.currentTimeMillis(),
    val lastRestockedDate: Long = System.currentTimeMillis(),
    val trackingStatus: String = "Healthy"
)
