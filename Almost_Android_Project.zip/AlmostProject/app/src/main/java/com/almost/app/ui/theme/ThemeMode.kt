package com.almost.app.ui.theme

enum class ThemeMode { SYSTEM, LIGHT, DARK }
