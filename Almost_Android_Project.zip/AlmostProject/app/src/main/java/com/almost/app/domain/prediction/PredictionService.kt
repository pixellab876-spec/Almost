package com.almost.app.domain.prediction

import com.almost.app.data.local.entity.InventoryItemEntity

 data class PredictionResult(val daysRemaining: Double?, val predictedFinishDate: Long?, val status: String, val confidence: String)
object PredictionService {
    fun calculate(item: InventoryItemEntity, currentTime: Long = System.currentTimeMillis()): PredictionResult {
        if (item.currentQuantity <= 0.0) return PredictionResult(0.0, currentTime, "Finished", "High")
        val usage = item.dailyUsageEstimate
        if (usage <= 0.0) return PredictionResult(null, null, "Prediction unavailable", "Low")
        val days = (item.currentQuantity / usage).coerceAtLeast(0.0)
        val finish = currentTime + (days * 86_400_000.0).toLong()
        val status = when { item.minimumQuantityThreshold > 0 && item.currentQuantity <= item.minimumQuantityThreshold -> "Running low"; days <= item.reminderLeadTime -> "Almost finished"; days <= item.reminderLeadTime * 2 -> "Running low"; else -> "Healthy" }
        return PredictionResult(days, finish, status, "Medium")
    }
}
