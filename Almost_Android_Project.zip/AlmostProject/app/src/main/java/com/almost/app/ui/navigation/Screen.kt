package com.almost.app.ui.navigation
sealed class Screen(val route: String) {
    data object Home : Screen("home")
    data object Add : Screen("add?itemId={itemId}") { fun route(id: Long? = null) = if (id == null) "add" else "add?itemId=$id" }
    data object Detail : Screen("detail/{itemId}") { fun route(id: Long) = "detail/$id" }
    data object Settings : Screen("settings")
}
