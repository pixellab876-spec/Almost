package com.almost.app.ui.screens.detail

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.almost.app.ui.viewmodel.ItemDetailViewModel

class ItemDetailFactory(private val application: Application, private val itemId: Long) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = ItemDetailViewModel(application, itemId) as T
}
