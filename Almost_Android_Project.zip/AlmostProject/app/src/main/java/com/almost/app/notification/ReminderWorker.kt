package com.almost.app.notification

import android.content.Context
import android.os.Build
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.almost.app.AlmostApplication
import com.almost.app.domain.prediction.PredictionService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class ReminderWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        try {
            val app = applicationContext as AlmostApplication
            val prefs = applicationContext.getSharedPreferences("almost_settings", Context.MODE_PRIVATE)
            if (!prefs.getBoolean("notifications", true)) return@withContext Result.success()
            app.database.inventoryDao().getAllItemsOnce().forEach { item ->
                val p = PredictionService.calculate(item)
                val type = when { item.currentQuantity <= 0.0 -> "finished"; p.daysRemaining != null && p.daysRemaining <= item.reminderLeadTime -> "low"; else -> null }
                if (type != null) {
                    val day = System.currentTimeMillis() / 86_400_000L
                    val existing = app.database.inventoryDao().findNotification(item.id, type, day)
                    if (existing == null) {
                        NotificationHelper.show(applicationContext, (item.id % Int.MAX_VALUE).toInt(), if (type == "finished") "${item.name} has run out" else "${item.name} is running low", if (type == "finished") "Restock this item when you can." else "Estimated to run out in ${p.daysRemaining?.toInt() ?: 0} day(s).")
                        app.database.inventoryDao().insertNotificationRecord(com.almost.app.data.local.entity.NotificationRecordEntity(inventoryItemId = item.id, reminderType = type, scheduledDate = day, isDelivered = true))
                    }
                }
            }
            Result.success()
        } catch (_: Exception) { Result.retry() }
    }
}
