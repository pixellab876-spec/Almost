package com.almost.app.data.repository

import com.almost.app.data.local.dao.InventoryDao
import com.almost.app.data.local.entity.*
import kotlinx.coroutines.flow.Flow

class InventoryRepository(private val dao: InventoryDao) {
    val allItems: Flow<List<InventoryItemEntity>> = dao.getAllItemsFlow()
    fun item(id: Long) = dao.getItemFlowById(id)
    suspend fun get(id: Long) = dao.getItemById(id)
    suspend fun save(item: InventoryItemEntity): Long = if (item.id == 0L) dao.insertItem(item) else { dao.updateItem(item); item.id }
    suspend fun delete(item: InventoryItemEntity) = dao.deleteItem(item)
    fun consumptionHistory(id: Long) = dao.consumptionHistory(id)
    fun restockHistory(id: Long) = dao.restockHistory(id)
    suspend fun consume(item: InventoryItemEntity, amount: Double) {
        require(amount > 0 && amount <= item.currentQuantity) { "Enter an amount greater than zero and no more than the current quantity." }
        val now = System.currentTimeMillis()
        dao.updateItem(item.copy(currentQuantity = item.currentQuantity - amount, lastUpdatedDate = now))
        dao.insertConsumptionRecord(ConsumptionRecordEntity(inventoryItemId = item.id, quantityConsumed = amount, timestamp = now))
    }
    suspend fun restock(item: InventoryItemEntity, amount: Double) {
        require(amount > 0) { "Restock amount must be greater than zero." }
        val now = System.currentTimeMillis()
        dao.updateItem(item.copy(currentQuantity = item.currentQuantity + amount, lastRestockedDate = now, lastUpdatedDate = now))
        dao.insertRestockRecord(RestockRecordEntity(inventoryItemId = item.id, quantityAdded = amount, timestamp = now))
    }
}
