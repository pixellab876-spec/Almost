package com.almost.app.data.local.entity
import androidx.room.Entity
import androidx.room.PrimaryKey
@Entity(tableName = "restock_records")
data class RestockRecordEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val inventoryItemId: Long, val quantityAdded: Double, val timestamp: Long = System.currentTimeMillis(), val notes: String? = null)
