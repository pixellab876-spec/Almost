package com.almost.app.ui.screens.add_edit

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.almost.app.ui.viewmodel.AddEditItemViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun AddEditItemScreen(itemId: Long?, onBack: () -> Unit, vm: AddEditItemViewModel = viewModel()) {
    var name by remember { mutableStateOf("") }; var category by remember { mutableStateOf("General") }; var quantity by remember { mutableStateOf("") }; var unit by remember { mutableStateOf("pieces") }; var usage by remember { mutableStateOf("") }; var lead by remember { mutableStateOf("3") }; var threshold by remember { mutableStateOf("0") }; var error by remember { mutableStateOf<String?>(null) }; var loaded by remember { mutableStateOf(false) }
    LaunchedEffect(itemId) { if (itemId != null && !loaded) { /* Load existing values through Room-backed detail editing is kept explicit below. */ loaded = true } }
    Scaffold(topBar = { TopAppBar(title = { Text(if (itemId == null) "Add essential" else "Edit essential") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") } }) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), label = { Text("Item name *") }, singleLine = true)
            OutlinedTextField(category, { category = it }, Modifier.fillMaxWidth(), label = { Text("Category") }, singleLine = true)
            OutlinedTextField(quantity, { quantity = it }, Modifier.fillMaxWidth(), label = { Text("Current quantity *") }, singleLine = true)
            OutlinedTextField(unit, { unit = it }, Modifier.fillMaxWidth(), label = { Text("Unit (kg, L, pieces, rolls, sheets)") }, singleLine = true)
            OutlinedTextField(usage, { usage = it }, Modifier.fillMaxWidth(), label = { Text("Average daily usage (optional)") }, singleLine = true)
            OutlinedTextField(lead, { lead = it }, Modifier.fillMaxWidth(), label = { Text("Reminder lead time (days)") }, singleLine = true)
            OutlinedTextField(threshold, { threshold = it }, Modifier.fillMaxWidth(), label = { Text("Minimum quantity threshold") }, singleLine = true)
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            Button(onClick = { vm.save(itemId, name, category, quantity, unit, usage, lead, threshold) { msg -> if (msg == null) onBack() else error = msg } }, Modifier.fillMaxWidth()) { Text("Save item") }
            if (itemId != null) Text("Note: edit prefill is not yet connected in this build; saving this form creates/updates based on entered values.", style = MaterialTheme.typography.bodySmall)
        }
    }
}
