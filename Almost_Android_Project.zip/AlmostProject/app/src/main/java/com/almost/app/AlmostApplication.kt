package com.almost.app

import android.app.Application
import androidx.room.Room
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.almost.app.data.local.AlmostDatabase
import com.almost.app.notification.ReminderWorker
import java.util.concurrent.TimeUnit

class AlmostApplication : Application() {
    val database: AlmostDatabase by lazy { Room.databaseBuilder(this, AlmostDatabase::class.java, "almost_database").fallbackToDestructiveMigration().build() }
    override fun onCreate() {
        super.onCreate()
        val request = PeriodicWorkRequestBuilder<ReminderWorker>(1, TimeUnit.DAYS).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("almost_reminder_check", ExistingPeriodicWorkPolicy.KEEP, request)
    }
}
