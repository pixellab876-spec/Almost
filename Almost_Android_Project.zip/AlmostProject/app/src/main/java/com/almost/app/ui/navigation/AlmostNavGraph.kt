package com.almost.app.ui.navigation

import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.almost.app.ui.screens.home.HomeScreen
import com.almost.app.ui.screens.add_edit.AddEditItemScreen
import com.almost.app.ui.screens.detail.ItemDetailScreen
import com.almost.app.ui.screens.settings.SettingsScreen
import com.almost.app.ui.viewmodel.SettingsViewModel

@Composable fun AlmostNavGraph(navController: NavHostController, settingsViewModel: SettingsViewModel) {
    NavHost(navController, startDestination = Screen.Home.route) {
        composable(Screen.Home.route) { HomeScreen(onAdd = { navController.navigate(Screen.Add.route()) }, onDetail = { navController.navigate(Screen.Detail.route(it)) }, onSettings = { navController.navigate(Screen.Settings.route) }) }
        composable(Screen.Add.route, arguments = listOf(navArgument("itemId") { type = NavType.StringType; nullable = true; defaultValue = null })) { entry -> AddEditItemScreen(entry.arguments?.getString("itemId")?.toLongOrNull(), onBack = { navController.popBackStack() }) }
        composable(Screen.Detail.route, arguments = listOf(navArgument("itemId") { type = NavType.LongType })) { entry -> ItemDetailScreen(entry.arguments?.getLong("itemId") ?: -1L, onBack = { navController.popBackStack() }, onEdit = { navController.navigate(Screen.Add.route(it)) { launchSingleTop = true } }, onDeleted = { navController.popBackStack() }) }
        composable(Screen.Settings.route) { SettingsScreen(settingsViewModel, onBack = { navController.popBackStack() }) }
    }
}
